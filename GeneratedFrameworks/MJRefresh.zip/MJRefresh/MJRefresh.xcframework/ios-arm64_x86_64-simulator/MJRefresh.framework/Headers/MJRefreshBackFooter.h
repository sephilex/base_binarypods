//
//  MJRefreshBackFooter.h
//  MJRefresh
//
//  Created by MJ Lee on 15/4/24.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#if __has_include(<MJRefresh/MJRefreshFooter.h>)
#import <MJRefresh/MJRefreshFooter.h>
#else
#import "MJRefreshFooter.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@interface MJRefreshBackFooter : MJRefreshFooter

@end

NS_ASSUME_NONNULL_END
